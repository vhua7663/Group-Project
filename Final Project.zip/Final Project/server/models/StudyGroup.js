const mongoose = require('mongoose')

const studyGroupSchema = new mongoose.Schema(
  {
    courseName: { type: String, required: [true, 'Course name is required'], trim: true },
    description: { type: String, required: [true, 'Description is required'] },
    location: { type: String, required: [true, 'Location is required'], trim: true },
    meetingTime: { type: String, required: [true, 'Meeting time is required'], trim: true },
    creator: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  },
  { timestamps: true }
)

module.exports = mongoose.model('StudyGroup', studyGroupSchema)