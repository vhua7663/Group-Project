const router = require('express').Router()

let groups = [
  {
    _id: '1',
    courseName: 'CS 101',
    description: 'Intro to programming study group',
    location: 'Library Room 2',
    meetingTime: 'Monday 6 PM'
  }
]

router.get('/', (req, res) => {
  res.json(groups)
})

router.post('/', (req, res) => {
  const { courseName, description, location, meetingTime } = req.body

  if (!courseName || !description || !location || !meetingTime) {
    return res.status(400).json({ message: 'All group fields are required' })
  }

  const newGroup = {
    _id: String(Date.now()),
    courseName,
    description,
    location,
    meetingTime
  }

  groups.push(newGroup)
  res.status(201).json(newGroup)
})

module.exports = router