const router = require('express').Router()

router.post('/register', (req, res) => {
  const { username, email, password } = req.body
  if (!username || !email || !password) {
    return res.status(400).json({ message: 'All fields are required' })
  }

  return res.status(201).json({
    token: 'demo-token',
    user: { username, email }
  })
})

router.post('/login', (req, res) => {
  const { email, password } = req.body
  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' })
  }

  return res.json({
    token: 'demo-token',
    user: { email }
  })
})

module.exports = router