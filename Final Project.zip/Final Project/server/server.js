require('dotenv').config()
const express = require('express')
const cors = require('cors')
const connectDB = require('./config/db')

const authRoutes = require('./routes/authRoutes')
const groupRoutes = require('./routes/groupRoutes')
const postRoutes = require('./routes/postRoutes')

const app = express()

connectDB()

app.use(cors())
app.use(express.json())

app.use('/api/auth', authRoutes)
app.use('/api/groups', groupRoutes)
app.use('/api/posts', postRoutes)

app.get('/', (req, res) => {
  res.send('Study Group Finder API running')
})

const PORT = process.env.PORT || 5000
app.listen(PORT, () => console.log(`Server running on port ${PORT}`))