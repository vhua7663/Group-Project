import { useEffect, useState } from 'react'
import GroupForm from '../components/GroupForm'
import GroupList from '../components/GroupList'
import { createGroup, getGroups } from '../services/api'

export default function Dashboard() {
  const [groups, setGroups] = useState([])

  const loadGroups = async () => {
    const data = await getGroups()
    setGroups(data.groups || data)
  }

  useEffect(() => {
    loadGroups()
  }, [])

  const handleCreate = async (formData) => {
    await createGroup(formData)
    await loadGroups()
  }

  return (
    <section className="container">
      <div className="card">
        <h1>Dashboard</h1>
        <p>Your Groups</p>
      </div>

      <div className="card">
        <GroupForm onCreate={handleCreate} />
      </div>

      <div className="card">
        <GroupList groups={groups} />
      </div>
    </section>
  )
}