import { useEffect, useState } from 'react'
import GroupList from '../components/GroupList'
import { getGroups } from '../services/api'

export default function Groups() {
  const [groups, setGroups] = useState([])

  useEffect(() => {
    getGroups().then((data) => setGroups(data.groups || data))
  }, [])

  return (
    <section className="container">
      <div className="card">
        <h1>All Study Groups</h1>
        <GroupList groups={groups} />
      </div>
    </section>
  )
}