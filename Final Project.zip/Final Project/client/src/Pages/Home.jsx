import React from 'react'
import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <section className="card center-text">
      <h1>Study Group Finder</h1>
      <p>Find, create, and join study groups for your college classes.</p>
      <div className="actions">
        <Link to="/register">Get Started</Link>
        <Link to="/groups">Browse Groups</Link>
      </div>
    </section>
  )
}