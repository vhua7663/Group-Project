export default function GroupList({ groups }) {
  if (!groups.length) {
    return <p>No groups found.</p>
  }

  return (
    <div className="grid">
      {groups.map((group) => (
        <div className="card" key={group._id || group.id}>
          <h3>{group.courseName || group.title}</h3>
          <p>{group.description}</p>
          <p>Location: {group.location}</p>
          <p>Time: {group.meetingTime || group.time}</p>
        </div>
      ))}
    </div>
  )
}