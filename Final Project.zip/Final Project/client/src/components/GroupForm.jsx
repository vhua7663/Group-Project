import { useState } from 'react'

export default function GroupForm({ onCreate }) {
  const [formData, setFormData] = useState({
    courseName: '',
    description: '',
    location: '',
    meetingTime: '',
  })

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    await onCreate(formData)
    setFormData({
      courseName: '',
      description: '',
      location: '',
      meetingTime: '',
    })
  }

  return (
    <form onSubmit={handleSubmit}>
      <input name="courseName" value={formData.courseName} onChange={handleChange} placeholder="Course Name" />
      <textarea name="description" value={formData.description} onChange={handleChange} placeholder="Description" />
      <input name="location" value={formData.location} onChange={handleChange} placeholder="Location" />
      <input name="meetingTime" value={formData.meetingTime} onChange={handleChange} placeholder="Meeting Time" />
      <button type="submit">Create Group</button>
    </form>
  )
}