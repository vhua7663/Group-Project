import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export async function registerUser(formData) {
  const { data } = await api.post('/auth/register', formData)
  return data
}

export async function loginUser(formData) {
  const { data } = await api.post('/auth/login', formData)
  return data
}

export async function getGroups() {
  const { data } = await api.get('/groups')
  return data
}

export async function createGroup(formData) {
  const { data } = await api.post('/groups', formData)
  return data
}