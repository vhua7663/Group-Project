import React, { createContext, useContext, useState } from 'react'
import { loginUser, registerUser } from '../services/api'

const AuthContext = createContext()

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)

  const login = async (formData) => {
    const data = await loginUser(formData)
    setUser(data.user || data)
    if (data.token) localStorage.setItem('token', data.token)
    return data
  }

  const register = async (formData) => {
    const data = await registerUser(formData)
    setUser(data.user || data)
    if (data.token) localStorage.setItem('token', data.token)
    return data
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('token')
  }

  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}